# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: critical-business.spec.ts >> CRITICAL-AUTH-001: real login and authenticated identity
- Location: tests/critical-business.spec.ts:85:1

# Error details

```
TimeoutError: page.waitForURL: Timeout 30000ms exceeded.
=========================== logs ===========================
waiting for navigation until "load"
  navigated to "http://localhost:15666/auth/login#/cockpit"
============================================================
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - navigation [ref=e6]:
      - link "总览" [ref=e7] [cursor=pointer]:
        - /url: "#/cockpit"
      - link "回路" [ref=e8] [cursor=pointer]:
        - /url: "#/cockpit/loops"
      - link "性能" [ref=e9] [cursor=pointer]:
        - /url: "#/cockpit/performance"
      - link "诊断" [ref=e10] [cursor=pointer]:
        - /url: "#/cockpit/diagnosis"
      - link "整定" [ref=e11] [cursor=pointer]:
        - /url: "#/cockpit/tuning"
      - link "处置" [ref=e12] [cursor=pointer]:
        - /url: "#/cockpit/handling"
    - heading "控制回路绩效监控驾驶舱" [level=1] [ref=e15]
    - generic [ref=e17]:
      - button "暂停自动刷新（5min/60s 轮询）" [ref=e18] [cursor=pointer]:
        - img [ref=e19]
      - button "手动刷新（全页重新拉取）" [ref=e23] [cursor=pointer]:
        - img [ref=e24]
      - generic [ref=e29]:
        - generic [ref=e30] [cursor=pointer]: 近 24h
        - generic [ref=e31] [cursor=pointer]: 近 7 天
        - generic [ref=e32] [cursor=pointer]: 近 30 天
      - generic [ref=e33]:
        - generic [ref=e34]: 19:28:03
        - generic [ref=e35]: 2026-10-17 星期六
      - button "切换浅色" [ref=e36] [cursor=pointer]:
        - img [ref=e37]
      - button "进入工作区" [ref=e41] [cursor=pointer]
      - button "管理后台" [ref=e42] [cursor=pointer]
  - generic [ref=e43]:
    - generic [ref=e44] [cursor=pointer]:
      - generic "综合评分 = 当前时间窗内参评回路评分加权均值（窗口均值口径）；回路总数卡内的等级分布为各回路最新快照口径，两者统计时点不同" [ref=e45]: 全厂综合评分窗口均值
      - generic [ref=e47]: —
      - generic [ref=e48]: 环比 —
    - generic [ref=e49]:
      - generic [ref=e50]: 自动投用率
      - generic [ref=e52]: —
      - generic [ref=e53]: 环比 —
    - generic [ref=e54]:
      - generic "五档等级分布按窗口内各回路最新一条评估快照判定（最新快照口径），与左一综合评分的窗口均值口径不同" [ref=e55]: 回路总数等级=最新快照
      - generic [ref=e57]: "28"
      - generic "五档等级分布（各回路最新快照口径）" [ref=e58]:
        - generic [ref=e59]: —
    - generic [ref=e60] [cursor=pointer]:
      - generic "劣化 = 窗口内最新快照等级为警告/不合格的回路数（最新快照口径）" [ref=e61]: 劣化回路数
      - generic [ref=e63]: "0"
      - generic [ref=e64]: 环比 → 0.00
    - generic [ref=e65] [cursor=pointer]:
      - generic [ref=e66]: 处置待办
      - generic [ref=e68]: "0"
      - generic [ref=e69]: 待处理 / 处理中 / 验证中
    - generic [ref=e70] [cursor=pointer]:
      - generic [ref=e71]: 预警事件
      - generic [ref=e73]: "0"
      - generic [ref=e74]: 时间窗内活跃
  - generic [ref=e75]:
    - generic [ref=e76]:
      - generic [ref=e77]:
        - text: 综合评分
        - generic [ref=e78]: 装置×单元 · 按评分降序 · 点击联动趋势/雷达
      - generic [ref=e80]:
        - generic [ref=e81]:
          - generic "CRITICAL-E2E-39028560853-1-AREA · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e82] [cursor=pointer]:
            - button "›" [ref=e83]
            - generic [ref=e84]: —
            - generic "CRITICAL-E2E-39028560853-1-AREA" [ref=e85]
            - generic [ref=e87]: —
          - generic "CRITICAL-E2E-39028560853-1-UNIT · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e89] [cursor=pointer]:
            - generic [ref=e90]: —
            - generic "CRITICAL-E2E-39028560853-1-UNIT" [ref=e91]
            - generic [ref=e93]: —
        - generic [ref=e94]:
          - generic "EO 装置 · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e95] [cursor=pointer]:
            - button "›" [ref=e96]
            - generic [ref=e97]: —
            - generic "EO 装置" [ref=e98]
            - generic [ref=e100]: —
          - generic [ref=e101]:
            - generic "急冷分离单元 · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e102] [cursor=pointer]:
              - generic [ref=e103]: —
              - generic "急冷分离单元" [ref=e104]
              - generic [ref=e106]: —
            - generic "精馏塔单元 · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e107] [cursor=pointer]:
              - generic [ref=e108]: —
              - generic "精馏塔单元" [ref=e109]
              - generic [ref=e111]: —
            - generic "醛化反应单元 · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e112] [cursor=pointer]:
              - generic [ref=e113]: —
              - generic "醛化反应单元" [ref=e114]
              - generic [ref=e116]: —
            - generic "脱甲烷精馏单元 · 综合评分 — · 排名 —（点击选中，再次点击取消）" [ref=e117] [cursor=pointer]:
              - generic [ref=e118]: —
              - generic "脱甲烷精馏单元" [ref=e119]
              - generic [ref=e121]: —
    - generic [ref=e123]:
      - text: 绩效趋势
      - generic [ref=e124]: 综合评分 / 自动投用率 · CRITICAL-E2E-39028560853-1-FACTORY 口径（等级分布序列暂未提供）
    - generic [ref=e130]:
      - generic [ref=e131]:
        - text: 六维绩效
        - generic [ref=e132]: CRITICAL-E2E-39028560853-1-FACTORY · 参评回路均值
      - generic [ref=e133]:
        - generic [ref=e135]: 暂无绩效数据
        - button "节点回路 →" [ref=e136] [cursor=pointer]
    - generic [ref=e137]:
      - generic [ref=e138]:
        - text: 单元平稳率
        - generic [ref=e139]: 按平稳率升序 · 目标 ≥92
      - generic [ref=e141]: 暂无单元数据
      - generic [ref=e142]:
        - text: 全厂平稳率
        - generic [ref=e143]: —%
        - text: · 达标（≥92）
        - generic [ref=e144]: 0/0
        - text: 单元
    - generic [ref=e145]:
      - generic [ref=e146]:
        - text: 单元自控率
        - generic [ref=e147]: 柱=自控率降序 · 折线=累计手动回路占比
      - generic [ref=e149]: 暂无单元自控率数据
    - generic [ref=e151]:
      - text: 回路适用性分布
      - generic [ref=e152]: 全厂 · L0~L4 最新快照口径
```

# Test source

```ts
  1   | /** P7-02 real services only. No route mocks or conditional business assertions.
  2   |  * Inputs come from prepare-critical-fixture.py in disposable CI services. No
  3   |  * product results are seeded; CALC submits the actual selected-loop task.
  4   |  */
  5   | import { readFileSync } from 'node:fs';
  6   | import { test, expect, type APIRequestContext, type Page } from '@playwright/test';
  7   | 
  8   | interface InputFixture {
  9   |   schemaVersion: number;
  10  |   synthetic: boolean;
  11  |   inputOnly: boolean;
  12  |   environment: string;
  13  |   candidateSha: string;
  14  |   loopId: string;
  15  |   loopTagName: string;
  16  |   windowStart: string;
  17  |   windowEnd: string;
  18  | }
  19  | 
  20  | const api = (process.env.E2E_API_BASE_URL ?? 'http://localhost:17101/api/v1').replace(/\/$/, '');
  21  | let fixture: InputFixture;
  22  | let taskId: string;
  23  | let snapshot: Record<string, any>;
  24  | const tokens = new Map<string, string>();
  25  | 
  26  | async function token(request: APIRequestContext, username = 'admin'): Promise<string> {
  27  |   const cached = tokens.get(username);
  28  |   if (cached) return cached;
  29  |   const response = await request.post(`${api}/auth/login`, {
  30  |     data: { username, password: 'admin123' },
  31  |   });
  32  |   expect(response.status()).toBe(200);
  33  |   const body = await response.json();
  34  |   expect(body.code).toBe('0');
  35  |   expect(body.data.user.username).toBe(username);
  36  |   expect(body.data.accessToken).toEqual(expect.any(String));
  37  |   tokens.set(username, body.data.accessToken);
  38  |   return body.data.accessToken;
  39  | }
  40  | 
  41  | async function read(request: APIRequestContext, path: string) {
  42  |   const response = await request.get(`${api}${path}`, {
  43  |     headers: { Authorization: `Bearer ${await token(request)}` },
  44  |   });
  45  |   expect(response.status(), path).toBe(200);
  46  |   const body = await response.json();
  47  |   expect(body.code, path).toBe('0');
  48  |   return body.data;
  49  | }
  50  | 
  51  | async function login(page: Page, username: string) {
  52  |   await page.addInitScript(() => localStorage.setItem('clpm-onboarding-completed', 'true'));
  53  |   await page.goto('/auth/login');
  54  |   await page.getByPlaceholder('请输入用户名').fill(username);
  55  |   await page.getByPlaceholder('请输入密码').fill('admin123');
  56  |   const responsePromise = page.waitForResponse(
  57  |     (response) =>
  58  |       new URL(response.url()).pathname === '/api/v1/auth/login' &&
  59  |       response.request().method() === 'POST',
  60  |   );
  61  |   await page.getByText('登录', { exact: true }).click();
  62  |   const response = await responsePromise;
  63  |   expect(response.status()).toBe(200);
  64  |   expect((await response.json()).data.user.username).toBe(username);
> 65  |   await page.waitForURL((url) => !url.pathname.includes('/auth/login'));
      |              ^ TimeoutError: page.waitForURL: Timeout 30000ms exceeded.
  66  |   await expect(page.locator('body')).not.toContainText('访问被拒绝');
  67  | }
  68  | 
  69  | test.describe.configure({ mode: 'serial' });
  70  | test.beforeAll(() => {
  71  |   expect(process.env.GITHUB_ACTIONS, 'business gate only writes in disposable CI').toBe('true');
  72  |   expect(process.env.POSTGRES_DB).toBe('clpm_critical_e2e');
  73  |   expect(process.env.TDENGINE_DB).toBe('clpm_critical_e2e_ts');
  74  |   const path = process.env.E2E_CRITICAL_FIXTURE;
  75  |   expect(path, 'required synthetic-input manifest from isolated CI preparation').toBeTruthy();
  76  |   fixture = JSON.parse(readFileSync(path!, 'utf8'));
  77  |   expect(fixture.schemaVersion).toBe(1);
  78  |   expect(fixture.synthetic).toBe(true);
  79  |   expect(fixture.inputOnly).toBe(true);
  80  |   expect(fixture.environment).toBe('disposable-github-ci');
  81  |   expect(fixture.loopTagName).toMatch(/^CRITICAL-E2E-\d+-\d+-FLOW001$/);
  82  |   expect(fixture.candidateSha).toBe(process.env.GITHUB_SHA);
  83  | });
  84  | 
  85  | test('CRITICAL-AUTH-001: real login and authenticated identity', async ({ page }) => {
  86  |   await login(page, 'admin');
  87  |   const responsePromise = page.waitForResponse(
  88  |     (response) => response.url().includes('/api/v1/loops') && response.request().method() === 'GET',
  89  |   );
  90  |   await page.goto('/config/loop');
  91  |   const response = await responsePromise;
  92  |   expect(response.status()).toBe(200);
  93  |   await expect(page.locator('.ant-table').first()).toBeVisible();
  94  |   expect((await response.json()).code).toBe('0');
  95  | });
  96  | 
  97  | test('CRITICAL-PERM-001: sponsor cannot run calculation or open workbench', async ({
  98  |   page,
  99  |   request,
  100 | }) => {
  101 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  102 |     headers: { Authorization: `Bearer ${await token(request, 'sponsor')}` },
  103 |     data: {
  104 |       loopIds: [fixture.loopId],
  105 |       metrics: ['GOOD_VALUE_RATE'],
  106 |       tsStart: fixture.windowStart,
  107 |       tsEnd: fixture.windowEnd,
  108 |     },
  109 |   });
  110 |   expect(response.status()).toBe(403);
  111 |   await login(page, 'sponsor');
  112 |   await page.goto(`/loop/workbench360?loopId=${fixture.loopId}`);
  113 |   await expect(page.locator('body')).toContainText(/访问被拒绝|没有权限|无权访问/);
  114 | });
  115 | 
  116 | test('CRITICAL-CALC-001: real task produces one successful synthetic-input result', async ({
  117 |   request,
  118 | }, info) => {
  119 |   test.setTimeout(240_000);
  120 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  121 |     headers: { Authorization: `Bearer ${await token(request)}` },
  122 |     data: {
  123 |       loopIds: [fixture.loopId],
  124 |       metrics: ['GOOD_VALUE_RATE', 'AUTO_MODE_RATE', 'STEADY_RATE'],
  125 |       tsStart: fixture.windowStart,
  126 |       tsEnd: fixture.windowEnd,
  127 |     },
  128 |   });
  129 |   expect(response.status()).toBe(200);
  130 |   const created = await response.json();
  131 |   expect(created.code).toBe('0');
  132 |   taskId = created.data.taskId;
  133 |   expect(taskId).toMatch(/^[\da-f-]{36}$/);
  134 |   let state: Record<string, any>;
  135 |   await expect
  136 |     .poll(
  137 |       async () => {
  138 |         state = await read(request, `/tasks/${taskId}`);
  139 |         return ['SUCCESS', 'FAILED', 'CANCELLED'].includes(state.status);
  140 |       },
  141 |       { timeout: 180_000, intervals: [1000, 2000] },
  142 |     )
  143 |     .toBe(true);
  144 |   await info.attach('task-terminal.json', {
  145 |     body: JSON.stringify(state!),
  146 |     contentType: 'application/json',
  147 |   });
  148 |   expect(state!.status).toBe('SUCCESS');
  149 |   expect(state!.loopsTotal).toBe(1);
  150 |   expect(state!.loopsDone).toBe(1);
  151 |   const results = await read(
  152 |     request,
  153 |     `/performance/loops/snapshots?latestOnly=false&taskId=${taskId}&loopId=${fixture.loopId}`,
  154 |   );
  155 |   expect(results.total).toBe(1);
  156 |   expect(results.items).toHaveLength(1);
  157 |   snapshot = results.items[0];
  158 |   await info.attach('snapshot.json', {
  159 |     body: JSON.stringify(snapshot),
  160 |     contentType: 'application/json',
  161 |   });
  162 |   expect(snapshot.loopId).toBe(fixture.loopId);
  163 |   expect(snapshot.sourceTaskId).toBe(taskId);
  164 |   expect(snapshot.status).toBe('SUCCESS');
  165 |   expect(snapshot.algorithmVersion).toMatch(/^KPI_CALC_/);
```