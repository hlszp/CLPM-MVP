# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: critical-business.spec.ts >> CRITICAL-PERM-001: sponsor cannot run calculation or open workbench
- Location: tests/critical-business.spec.ts:144:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('body')
Expected pattern: /访问被拒绝|没有权限|无权访问/
Received string:  "哎呀！未找到页面抱歉，我们无法找到您要找的页面。 返回首页"
Timeout: 10000ms

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for locator('body')
    2 × locator resolved to <body>…</body>
      - unexpected value "总览回路性能诊断整定处置控制回路绩效监控驾驶舱近 24h近 7 天近 30 天20:12:502026-10-17 星期六 进入工作区  全厂综合评分窗口均值…环比 —自动投用率…环比 — 回路总数等级=最新快照…— 劣化回路数 …环比 —处置待办…待处理 / 处理中 / 验证中预警事件…时间窗内活跃 综合评分 装置×单元 · 按评分降序 · 点击联动趋势/雷达加载中… 绩效趋势  综合评分 / 自动投用率 · 全厂口径（等级分布序列暂未提供） 加载中… 六维绩效 全厂/装置/单元 · 参评回路均值 组织树加载失败，暂无六维绩效数据  单元平稳率 按平稳率升序 · 目标 ≥92加载中… 全厂平稳率 —% · 达标（≥92）0/0 单元  单元自控率 柱=自控率降序 · 折线=累计手动回路占比加载中… 回路适用性分布 全厂 · L0~L4 最新快照口径加载中…登录成功欢迎回来:项目发起人"
    - locator resolved to <body>…</body>
    - unexpected value "总览回路性能诊断整定处置控制回路绩效监控驾驶舱近 24h近 7 天近 30 天20:12:502026-10-17 星期六 进入工作区  全厂综合评分窗口均值…环比 —自动投用率…环比 — 回路总数等级=最新快照…— 劣化回路数 …环比 —处置待办…待处理 / 处理中 / 验证中预警事件…时间窗内活跃 综合评分 装置×单元 · 按评分降序 · 点击联动趋势/雷达加载中… 绩效趋势  综合评分 / 自动投用率 · 全厂口径（等级分布序列暂未提供）  六维绩效 全厂/装置/单元 · 参评回路均值 组织树加载失败，暂无六维绩效数据  单元平稳率 按平稳率升序 · 目标 ≥92加载中… 全厂平稳率 —% · 达标（≥92）0/0 单元  单元自控率 柱=自控率降序 · 折线=累计手动回路占比加载中… 回路适用性分布 全厂 · L0~L4 最新快照口径登录成功欢迎回来:项目发起人"
    - locator resolved to <body>…</body>
    - unexpected value "总览回路性能诊断整定处置控制回路绩效监控驾驶舱近 24h近 7 天近 30 天20:12:502026-10-17 星期六 进入工作区  全厂综合评分窗口均值—环比 —自动投用率—环比 — 回路总数等级=最新快照28— 劣化回路数 0 环比 → 0.00处置待办0待处理 / 处理中 / 验证中预警事件0时间窗内活跃 综合评分 装置×单元 · 按评分降序 · 点击联动趋势/雷达 › —CRITICAL-E2E-39031454818-1-AREA——CRITICAL-E2E-39031454818-1-UNIT— › —EO 装置——急冷分离单元——精馏塔单元——醛化反应单元——脱甲烷精馏单元— 绩效趋势  综合评分 / 自动投用率 · 全厂口径（等级分布序列暂未提供）  六维绩效 全厂/装置/单元 · 参评回路均值 组织树加载失败，暂无六维绩效数据  单元平稳率 按平稳率升序 · 目标 ≥92暂无单元数据 全厂平稳率 —% · 达标（≥92）0/0 单元  单元自控率 柱=自控率降序 · 折线=累计手动回路占比加载中… 回路适用性分布 全厂 · L0~L4 最新快照口径登录成功欢迎回来:项目发起人"
    6 × locator resolved to <body>…</body>
      - unexpected value "哎呀！未找到页面抱歉，我们无法找到您要找的页面。 返回首页登录成功欢迎回来:项目发起人"
    14 × locator resolved to <body>…</body>
       - unexpected value "哎呀！未找到页面抱歉，我们无法找到您要找的页面。 返回首页"

```

```yaml
- img
- paragraph: 哎呀！未找到页面
- paragraph: 抱歉，我们无法找到您要找的页面。
- button "返回首页"
```

# Test source

```ts
  60  |       (route.pathname === '/cockpit' || route.pathname.startsWith('/cockpit/'));
  61  |   } catch {
  62  |     return false;
  63  |   }
  64  | }
  65  | 
  66  | async function gotoApplicationRoute(page: Page, path: string) {
  67  |   await page.goto(applicationRouteUrl(new URL(page.url()), path));
  68  | }
  69  | 
  70  | async function token(request: APIRequestContext, username = 'admin'): Promise<string> {
  71  |   const cached = tokens.get(username);
  72  |   if (cached) return cached;
  73  |   const response = await request.post(`${api}/auth/login`, {
  74  |     data: { username, password: 'admin123' },
  75  |   });
  76  |   expect(response.status()).toBe(200);
  77  |   const body = await response.json();
  78  |   expect(body.code).toBe('0');
  79  |   expect(body.data.user.username).toBe(username);
  80  |   expect(body.data.accessToken).toEqual(expect.any(String));
  81  |   tokens.set(username, body.data.accessToken);
  82  |   return body.data.accessToken;
  83  | }
  84  | 
  85  | async function read(request: APIRequestContext, path: string) {
  86  |   const response = await request.get(`${api}${path}`, {
  87  |     headers: { Authorization: `Bearer ${await token(request)}` },
  88  |   });
  89  |   expect(response.status(), path).toBe(200);
  90  |   const body = await response.json();
  91  |   expect(body.code, path).toBe('0');
  92  |   return body.data;
  93  | }
  94  | 
  95  | async function login(page: Page, username: string) {
  96  |   await page.addInitScript(() => localStorage.setItem('clpm-onboarding-completed', 'true'));
  97  |   await page.goto('/');
  98  |   await page.getByPlaceholder('请输入用户名').fill(username);
  99  |   await page.getByPlaceholder('请输入密码').fill('admin123');
  100 |   const responsePromise = page.waitForResponse(
  101 |     (response) =>
  102 |       new URL(response.url()).pathname === '/api/v1/auth/login' &&
  103 |       response.request().method() === 'POST',
  104 |   );
  105 |   const origin = new URL(page.url()).origin;
  106 |   await page.getByText('登录', { exact: true }).click();
  107 |   const response = await responsePromise;
  108 |   expect(response.status()).toBe(200);
  109 |   expect((await response.json()).data.user.username).toBe(username);
  110 |   // The isolated admin/sponsor seeds both land at /cockpit. Hash fragments
  111 |   // carry the actual route in the production build; arbitrary hashes cannot pass.
  112 |   await page.waitForURL((url) => isAuthenticatedLanding(url, origin));
  113 |   await expect(page.locator('body')).not.toContainText('访问被拒绝');
  114 | }
  115 | 
  116 | test.describe.configure({ mode: 'serial' });
  117 | test.beforeAll(() => {
  118 |   expect(process.env.GITHUB_ACTIONS, 'business gate only writes in disposable CI').toBe('true');
  119 |   expect(process.env.POSTGRES_DB).toBe('clpm_critical_e2e');
  120 |   expect(process.env.TDENGINE_DB).toBe('clpm_critical_e2e_ts');
  121 |   const path = process.env.E2E_CRITICAL_FIXTURE;
  122 |   expect(path, 'required synthetic-input manifest from isolated CI preparation').toBeTruthy();
  123 |   fixture = JSON.parse(readFileSync(path!, 'utf8'));
  124 |   expect(fixture.schemaVersion).toBe(1);
  125 |   expect(fixture.synthetic).toBe(true);
  126 |   expect(fixture.inputOnly).toBe(true);
  127 |   expect(fixture.environment).toBe('disposable-github-ci');
  128 |   expect(fixture.loopTagName).toMatch(/^CRITICAL-E2E-\d+-\d+-FLOW001$/);
  129 |   expect(fixture.candidateSha).toBe(process.env.GITHUB_SHA);
  130 | });
  131 | 
  132 | test('CRITICAL-AUTH-001: real login and authenticated identity', async ({ page }) => {
  133 |   await login(page, 'admin');
  134 |   const responsePromise = page.waitForResponse(
  135 |     (response) => response.url().includes('/api/v1/loops') && response.request().method() === 'GET',
  136 |   );
  137 |   await gotoApplicationRoute(page, '/config/loop');
  138 |   const response = await responsePromise;
  139 |   expect(response.status()).toBe(200);
  140 |   await expect(page.locator('.ant-table').first()).toBeVisible();
  141 |   expect((await response.json()).code).toBe('0');
  142 | });
  143 | 
  144 | test('CRITICAL-PERM-001: sponsor cannot run calculation or open workbench', async ({
  145 |   page,
  146 |   request,
  147 | }) => {
  148 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  149 |     headers: { Authorization: `Bearer ${await token(request, 'sponsor')}` },
  150 |     data: {
  151 |       loopIds: [fixture.loopId],
  152 |       metrics: ['GOOD_VALUE_RATE'],
  153 |       tsStart: fixture.windowStart,
  154 |       tsEnd: fixture.windowEnd,
  155 |     },
  156 |   });
  157 |   expect(response.status()).toBe(403);
  158 |   await login(page, 'sponsor');
  159 |   await gotoApplicationRoute(page, `/loop/workbench360?loopId=${fixture.loopId}`);
> 160 |   await expect(page.locator('body')).toContainText(/访问被拒绝|没有权限|无权访问/);
      |                                      ^ Error: expect(locator).toContainText(expected) failed
  161 | });
  162 | 
  163 | test('CRITICAL-CALC-001: real task produces one successful synthetic-input result', async ({
  164 |   request,
  165 | }, info) => {
  166 |   test.setTimeout(240_000);
  167 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  168 |     headers: { Authorization: `Bearer ${await token(request)}` },
  169 |     data: {
  170 |       loopIds: [fixture.loopId],
  171 |       metrics: ['GOOD_VALUE_RATE', 'AUTO_MODE_RATE', 'STEADY_RATE'],
  172 |       tsStart: fixture.windowStart,
  173 |       tsEnd: fixture.windowEnd,
  174 |     },
  175 |   });
  176 |   expect(response.status()).toBe(200);
  177 |   const created = await response.json();
  178 |   expect(created.code).toBe('0');
  179 |   taskId = created.data.taskId;
  180 |   expect(taskId).toMatch(/^[\da-f-]{36}$/);
  181 |   let state: Record<string, any>;
  182 |   await expect
  183 |     .poll(
  184 |       async () => {
  185 |         state = await read(request, `/tasks/${taskId}`);
  186 |         return ['SUCCESS', 'FAILED', 'CANCELLED'].includes(state.status);
  187 |       },
  188 |       { timeout: 180_000, intervals: [1000, 2000] },
  189 |     )
  190 |     .toBe(true);
  191 |   await info.attach('task-terminal.json', {
  192 |     body: JSON.stringify(state!),
  193 |     contentType: 'application/json',
  194 |   });
  195 |   expect(state!.status).toBe('SUCCESS');
  196 |   expect(state!.loopsTotal).toBe(1);
  197 |   expect(state!.loopsDone).toBe(1);
  198 |   const results = await read(
  199 |     request,
  200 |     `/performance/loops/snapshots?latestOnly=false&taskId=${taskId}&loopId=${fixture.loopId}`,
  201 |   );
  202 |   expect(results.total).toBe(1);
  203 |   expect(results.items).toHaveLength(1);
  204 |   snapshot = results.items[0];
  205 |   await info.attach('snapshot.json', {
  206 |     body: JSON.stringify(snapshot),
  207 |     contentType: 'application/json',
  208 |   });
  209 |   expect(snapshot.loopId).toBe(fixture.loopId);
  210 |   expect(snapshot.sourceTaskId).toBe(taskId);
  211 |   expect(snapshot.status).toBe('SUCCESS');
  212 |   expect(snapshot.algorithmVersion).toMatch(/^KPI_CALC_/);
  213 |   expect(snapshot.resultRecordId).toMatch(/^[\da-f-]{36}$/);
  214 |   expect(snapshot.dataLineage.dataBlockIds.length).toBeGreaterThan(0);
  215 |   for (const field of ['goodValueRate', 'autoModeRate', 'steadyRate']) {
  216 |     expect(typeof snapshot[field], field).toBe('number');
  217 |     expect(snapshot[field], field).toBeGreaterThanOrEqual(0);
  218 |     expect(snapshot[field], field).toBeLessThanOrEqual(100);
  219 |   }
  220 | });
  221 | 
  222 | test('CRITICAL-EVIDENCE-001: task projection links immutable result and real history UI', async ({
  223 |   request,
  224 |   page,
  225 | }, info) => {
  226 |   expect(taskId, 'CALC must finish before evidence checks').toBeTruthy();
  227 |   const record = await read(
  228 |     request,
  229 |     `/performance/loops/result-records/${snapshot.resultRecordId}`,
  230 |   );
  231 |   await info.attach('result-record.json', {
  232 |     body: JSON.stringify(record),
  233 |     contentType: 'application/json',
  234 |   });
  235 |   expect(record.recordId).toBe(snapshot.resultRecordId);
  236 |   expect(record.objectId).toBe(fixture.loopId);
  237 |   expect(record.status).toBe('COMPLETED');
  238 |   expect(record.algorithmVersion).toBe(snapshot.algorithmVersion);
  239 |   expect(record.payload.customTaskId).toBe(taskId);
  240 |   expect(record.payload.snapshotStatus).toBe('SUCCESS');
  241 |   expect(record.datasetSnapshotId).toMatch(/^[\da-f-]{36}$/);
  242 |   expect(record.configRevision).toMatch(/^(digest:[\da-f]{16}|rev:[^:]+:[\da-f]{16})$/);
  243 |   await login(page, 'admin');
  244 |   const historyResponse = page.waitForResponse((response) => {
  245 |     const url = new URL(response.url());
  246 |     return url.pathname === '/api/v1/performance/loops/snapshots' &&
  247 |       url.searchParams.get('taskId') === taskId && response.request().method() === 'GET';
  248 |   });
  249 |   await gotoApplicationRoute(page, `/metric/loop-evaluation?view=history&taskId=${taskId}`);
  250 |   await expect.poll(() => {
  251 |     const route = applicationRoute(new URL(page.url()));
  252 |     return { path: route.pathname, view: route.searchParams.get('view'), taskId: route.searchParams.get('taskId') };
  253 |   }).toEqual({ path: '/metric/loop-evaluation', view: 'history', taskId });
  254 |   const history = await historyResponse;
  255 |   expect(history.status()).toBe(200);
  256 |   const projected = await history.json();
  257 |   expect(projected.code).toBe('0');
  258 |   expect(projected.data.total).toBe(1);
  259 |   expect(projected.data.items).toHaveLength(1);
  260 |   expect(projected.data.items[0].sourceTaskId).toBe(taskId);
```