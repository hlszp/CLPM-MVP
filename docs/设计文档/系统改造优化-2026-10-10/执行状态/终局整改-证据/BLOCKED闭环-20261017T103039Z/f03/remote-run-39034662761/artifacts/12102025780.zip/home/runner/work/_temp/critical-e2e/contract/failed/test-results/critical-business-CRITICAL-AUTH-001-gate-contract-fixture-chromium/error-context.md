# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: critical-business.spec.ts >> CRITICAL-AUTH-001: gate-contract fixture
- Location: tests/critical-business.spec.ts:3:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  |     test('CRITICAL-AUTH-001: gate-contract fixture', async ({}, testInfo) => {
  4  |       
> 5  |       expect(false).toBe(true);
     |                     ^ Error: expect(received).toBe(expected) // Object.is equality
  6  |     });
  7  |   
  8  | 
  9  |     test('CRITICAL-PERM-001: gate-contract fixture', async ({}, testInfo) => {
  10 |       
  11 |       expect(true).toBe(true);
  12 |     });
  13 |   
  14 | 
  15 |     test('CRITICAL-CALC-001: gate-contract fixture', async ({}, testInfo) => {
  16 |       
  17 |       expect(true).toBe(true);
  18 |     });
  19 |   
  20 | 
  21 |     test('CRITICAL-EVIDENCE-001: gate-contract fixture', async ({}, testInfo) => {
  22 |       
  23 |       expect(true).toBe(true);
  24 |     });
  25 |   
```