# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: critical-business.spec.ts >> CRITICAL-CALC-001: real task produces one successful synthetic-input result
- Location: tests/critical-business.spec.ts:230:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0
```

# Test source

```ts
  164 |   page,
  165 |   request,
  166 |   browser,
  167 |   baseURL,
  168 | }, info) => {
  169 |   const headers = { Authorization: `Bearer ${await token(request, 'sponsor')}` };
  170 |   const me = await request.get(`${api}/auth/me`, { headers });
  171 |   expect(me.status()).toBe(200);
  172 |   const identity = await me.json();
  173 |   expect(identity.code).toBe('0');
  174 |   expect(identity.data.username).toBe('sponsor');
  175 |   expect(identity.data.role).toBe('SPONSOR');
  176 |   expect(Array.isArray(identity.data.pageCodes)).toBe(true);
  177 |   expect(Array.isArray(identity.data.permissions)).toBe(true);
  178 |   expect(identity.data.pageCodes).not.toContain('page:workbench.main');
  179 |   expect(identity.data.permissions).not.toContain('metric:task-run');
  180 |   await info.attach('sponsor-identity.json', {
  181 |     body: JSON.stringify(identity), contentType: 'application/json',
  182 |   });
  183 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  184 |     headers,
  185 |     data: {
  186 |       loopIds: [fixture.loopId],
  187 |       metrics: ['GOOD_VALUE_RATE'],
  188 |       tsStart: fixture.windowStart,
  189 |       tsEnd: fixture.windowEnd,
  190 |     },
  191 |   });
  192 |   expect(response.status()).toBe(403);
  193 |   const denied = await response.json();
  194 |   expect(denied.code).toBe('ERR_PERMISSION_DENIED');
  195 |   expect(denied.data).toBeNull();
  196 |   await info.attach('sponsor-write-denied.json', {
  197 |     body: JSON.stringify(denied), contentType: 'application/json',
  198 |   });
  199 |   await login(page, 'sponsor');
  200 |   const target = `/loop/workbench360?loopId=${fixture.loopId}`;
  201 |   await gotoApplicationRoute(page, target);
  202 |   await expect.poll(() => {
  203 |     const route = applicationRoute(new URL(page.url()));
  204 |     return `${route.pathname}${route.search}`;
  205 |   }).toBe(target);
  206 |   // Page-code filtering removes this route AND its known-path pattern. The
  207 |   // current router therefore renders its exact 404 fallback for this denial.
  208 |   await expect(page.getByText('哎呀！未找到页面', { exact: true })).toBeVisible();
  209 |   await expect(page.getByText('抱歉，我们无法找到您要找的页面。', { exact: true })).toBeVisible();
  210 |   await expect(page.locator('.wb360-adapter')).toHaveCount(0);
  211 |   // An independent authenticated context proves the target actually exists.
  212 |   // Reusing the sponsor context would preserve its localStorage credentials.
  213 |   const adminContext = await browser.newContext({ baseURL });
  214 |   try {
  215 |     const adminPage = await adminContext.newPage();
  216 |     await login(adminPage, 'admin');
  217 |     await gotoApplicationRoute(adminPage, target);
  218 |     await expect.poll(() => {
  219 |       const route = applicationRoute(new URL(adminPage.url()));
  220 |       return `${route.pathname}${route.search}`;
  221 |     }).toBe(target);
  222 |     await expect(adminPage.locator('.wb360-adapter')).toBeVisible();
  223 |     await expect(adminPage.locator('.wb360-adapter-state')).toHaveCount(0);
  224 |     await expect(adminPage.getByText('哎呀！未找到页面', { exact: true })).toHaveCount(0);
  225 |   } finally {
  226 |     await adminContext.close();
  227 |   }
  228 | });
  229 | 
  230 | test('CRITICAL-CALC-001: real task produces one successful synthetic-input result', async ({
  231 |   request,
  232 | }, info) => {
  233 |   test.setTimeout(240_000);
  234 |   const response = await request.post(`${api}/tasks/custom/evaluate`, {
  235 |     headers: { Authorization: `Bearer ${await token(request)}` },
  236 |     data: {
  237 |       loopIds: [fixture.loopId],
  238 |       metrics: ['GOOD_VALUE_RATE', 'AUTO_MODE_RATE', 'STEADY_RATE'],
  239 |       tsStart: fixture.windowStart,
  240 |       tsEnd: fixture.windowEnd,
  241 |     },
  242 |   });
  243 |   expect(response.status()).toBe(200);
  244 |   const created = await response.json();
  245 |   expect(created.code).toBe('0');
  246 |   taskId = created.data.taskId;
  247 |   expect(taskId).toMatch(/^[\da-f-]{36}$/);
  248 |   let state: Record<string, any>;
  249 |   await expect
  250 |     .poll(
  251 |       async () => {
  252 |         state = await read(request, `/tasks/${taskId}`);
  253 |         return ['SUCCESS', 'FAILED', 'CANCELLED'].includes(state.status);
  254 |       },
  255 |       { timeout: 180_000, intervals: [1000, 2000] },
  256 |     )
  257 |     .toBe(true);
  258 |   await info.attach('task-terminal.json', {
  259 |     body: JSON.stringify(state!),
  260 |     contentType: 'application/json',
  261 |   });
  262 |   expect(state!.status).toBe('SUCCESS');
  263 |   expect(state!.loopsTotal).toBe(1);
> 264 |   expect(state!.loopsDone).toBe(1);
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  265 |   const results = await read(
  266 |     request,
  267 |     `/performance/loops/snapshots?latestOnly=false&taskId=${taskId}&loopId=${fixture.loopId}`,
  268 |   );
  269 |   expect(results.total).toBe(1);
  270 |   expect(results.items).toHaveLength(1);
  271 |   snapshot = results.items[0];
  272 |   await info.attach('snapshot.json', {
  273 |     body: JSON.stringify(snapshot),
  274 |     contentType: 'application/json',
  275 |   });
  276 |   expect(snapshot.loopId).toBe(fixture.loopId);
  277 |   expect(snapshot.sourceTaskId).toBe(taskId);
  278 |   expect(snapshot.status).toBe('SUCCESS');
  279 |   expect(snapshot.algorithmVersion).toMatch(/^KPI_CALC_/);
  280 |   expect(snapshot.resultRecordId).toMatch(/^[\da-f-]{36}$/);
  281 |   expect(snapshot.dataLineage.dataBlockIds.length).toBeGreaterThan(0);
  282 |   for (const field of ['goodValueRate', 'autoModeRate', 'steadyRate']) {
  283 |     expect(typeof snapshot[field], field).toBe('number');
  284 |     expect(snapshot[field], field).toBeGreaterThanOrEqual(0);
  285 |     expect(snapshot[field], field).toBeLessThanOrEqual(100);
  286 |   }
  287 | });
  288 | 
  289 | test('CRITICAL-EVIDENCE-001: task projection links immutable result and real history UI', async ({
  290 |   request,
  291 |   page,
  292 | }, info) => {
  293 |   expect(taskId, 'CALC must finish before evidence checks').toBeTruthy();
  294 |   const record = await read(
  295 |     request,
  296 |     `/performance/loops/result-records/${snapshot.resultRecordId}`,
  297 |   );
  298 |   await info.attach('result-record.json', {
  299 |     body: JSON.stringify(record),
  300 |     contentType: 'application/json',
  301 |   });
  302 |   expect(record.recordId).toBe(snapshot.resultRecordId);
  303 |   expect(record.objectId).toBe(fixture.loopId);
  304 |   expect(record.status).toBe('COMPLETED');
  305 |   expect(record.algorithmVersion).toBe(snapshot.algorithmVersion);
  306 |   expect(record.payload.customTaskId).toBe(taskId);
  307 |   expect(record.payload.snapshotStatus).toBe('SUCCESS');
  308 |   expect(record.datasetSnapshotId).toMatch(/^[\da-f-]{36}$/);
  309 |   expect(record.configRevision).toMatch(/^(digest:[\da-f]{16}|rev:[^:]+:[\da-f]{16})$/);
  310 |   await login(page, 'admin');
  311 |   const historyResponse = page.waitForResponse((response) => {
  312 |     const url = new URL(response.url());
  313 |     return url.pathname === '/api/v1/performance/loops/snapshots' &&
  314 |       url.searchParams.get('taskId') === taskId && response.request().method() === 'GET';
  315 |   });
  316 |   await gotoApplicationRoute(page, `/metric/loop-evaluation?view=history&taskId=${taskId}`);
  317 |   await expect.poll(() => {
  318 |     const route = applicationRoute(new URL(page.url()));
  319 |     return { path: route.pathname, view: route.searchParams.get('view'), taskId: route.searchParams.get('taskId') };
  320 |   }).toEqual({ path: '/metric/loop-evaluation', view: 'history', taskId });
  321 |   const history = await historyResponse;
  322 |   expect(history.status()).toBe(200);
  323 |   const projected = await history.json();
  324 |   expect(projected.code).toBe('0');
  325 |   expect(projected.data.total).toBe(1);
  326 |   expect(projected.data.items).toHaveLength(1);
  327 |   expect(projected.data.items[0].sourceTaskId).toBe(taskId);
  328 |   expect(projected.data.items[0].resultRecordId).toBe(snapshot.resultRecordId);
  329 |   const row = page
  330 |     .locator('.ant-table-tbody tr.ant-table-row')
  331 |     .filter({ hasText: fixture.loopTagName });
  332 |   await expect(row).toHaveCount(1);
  333 |   await row.getByRole('button', { name: /详情/ }).click();
  334 |   const drawer = page.locator('.ant-drawer:visible');
  335 |   await expect(drawer).toContainText(snapshot.algorithmVersion);
  336 |   await expect(drawer).toContainText('数据血缘');
  337 |   for (const id of snapshot.dataLineage.dataBlockIds) await expect(drawer).toContainText(id);
  338 | });
  339 | 
```